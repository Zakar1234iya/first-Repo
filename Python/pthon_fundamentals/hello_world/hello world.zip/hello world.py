print ("hello world ")

name = "neolle"
print("my name is ", name)
print("my name is" + name)


num = 42
print("number is ",num)
# print("number is " + num) must show an error /can only concatenate str (not "int") to str/

fav_food= 'sushi'
fav_food2= 'pizza'
print("I love {} and {} ".format(fav_food,fav_food2))
print(f"I love {fav_food} and {fav_food2} ")



