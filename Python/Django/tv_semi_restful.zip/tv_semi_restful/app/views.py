from django.shortcuts import *
from .models import *

def index(request):
    return redirect("/shows")



def show_all(request):
    pass



def add_new(request):
    pass



def create_new(request):
    pass



def view_show(request , id):
    pass



def edit_show(request , id):
    pass



def update_show(request, id):
    pass


def delete_show(request, id):
    pass


