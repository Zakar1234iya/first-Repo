var likesI = 9;

function increaseLikesI() {
    likesI++;
    let labelI = document.querySelector('#LikesLabel1');
    labelI.innerText = likesI;
};

var likesII = 12;

function increaseLikesII() {
    likesII++;
    let labelII = document.querySelector('#LikesLabel2');
    labelII.innerText = likesII;
};

var likesIII = 9;

function increaseLikesIII() {
    likesIII++;
    let labelIII = document.querySelector('#LikesLabel3');
    labelIII.innerText = likesIII;
};

