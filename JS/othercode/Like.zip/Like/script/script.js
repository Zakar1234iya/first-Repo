var likes = 3;

function increaseLikes() {
    likes++;
    let label = document.querySelector('#LikesLabel');
    label.innerText = likes;
}