

function increaseLikes(i){
    let element = document.getElementById(i);
    element.innerText = parseInt(element.innerText) +1;
}

